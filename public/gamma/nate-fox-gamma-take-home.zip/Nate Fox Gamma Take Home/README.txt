NATE FOX
Gamma, AI Creative Strategist take-home

  "Need a deck? just a sec."
  heynatefox.com/gamma

VIDEO  1080x1920, 9:16, 20.00s, 30fps, H.264, scored, captions burned in.
  natefox_gamma_hook1_person_20s_1080x1920.mp4      Hook A, person
  natefox_gamma_hook2_chat_20s_1080x1920.mp4        Hook B, channel
  natefox_gamma_hook3_titlecard_20s_1080x1920.mp4   Hook C, title card

  One spine, three openers. All three run the same middle: one unbroken
  11.1s product take, the finished deck becomes a Send button, then each
  closes in the world it opened in.

STATIC  PNG at the trafficked sizes.
  natefox_gamma_static_4x5_1080x1350.png
  natefox_gamma_static_1x1_1080x1080.png
  natefox_gamma_static_9x16_1080x1920.png

Built for Meta feed and Reels.
Process note, layer detail and alternate directions: heynatefox.com/gamma

Nate Fox  ·  heynatefox.com  ·  nathanfox.sf@gmail.com

Spec work. Not affiliated with, commissioned by, or endorsed by Gamma.
