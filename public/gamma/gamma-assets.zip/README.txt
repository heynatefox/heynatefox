Need a deck? just a sec.
Gamma, AI Creative Strategist take-home. Nate Fox, heynatefox.com/gamma

VIDEO  1080x1920, 9:16, 20.00s, 30fps, H.264, scored, captions burned in.
  gamma_hook1_person_20s_1080x1920.mp4      Hook A, person
  gamma_hook2_chat_20s_1080x1920.mp4        Hook B, channel
  gamma_hook3_titlecard_20s_1080x1920.mp4   Hook C, title card

STATIC  PNG at the trafficked sizes.
  gamma_static_4x5_1080x1350.png
  gamma_static_1x1_1080x1080.png
  gamma_static_9x16_1080x1920.png

Built for Meta feed and Reels. Spec work, not affiliated with Gamma.
